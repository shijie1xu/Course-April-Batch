package com.interview.coding.course;

//a parking lot with multiple floors and each floor multiple spots
//spot type: MOTOCYCLE, COMPACT, LARGE
//vehicle type: MOTOCYCLE, CAR, BUS
//MOTOCYCLE can park any spot, CAR can only park in COMPACT and LARGE, BUS only in LARGE spot
//assume no ticket, free parking
//1. display all available parking spots when car vehicle enters
//2. implement the park method
//3. follow-up: give the car option to choose a spot

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collector;
import java.util.stream.Collectors;

class Homework_ParkingDeck {
    List<Spot> spots;

    public Homework_ParkingDeck(List<Spot> spots) {
        //initialize all spots;
    }

    public List<Spot> showAllAvailableSpots() {
        //TODO: show all available spots when car enter the spot
        return null;
    }

    public List<Spot> showAllAvailableSpotsForVehicle(Vehicle vehicle) {
        //TODO: show all available spots when car enter the spot
        return null;
    }

    public List<Spot> showAllAvailableSpotsByFloor(int floorNumber) {
        //TODO: show all available spots when car enter the spot
        return null;
    }

    public void park(Vehicle vehicle) {
        Spot spot = applyParkingRule(vehicle);
        for (Spot s : spots) {
            if (spot.getSpotId() == s.getSpotId() && spot.getFloorNumber() == s.getFloorNumber()) {
                s.setAvailable(false);
                s.setVehicle(vehicle);
            }
        }

    }

    public Spot applyParkingRule(Vehicle vehicle) {
        //a motocycle can park in any spots
        //a car can park in either single compact spot or single large spot
        List<Spot> list = new ArrayList<>();

        if (vehicle.getVehicleType().equals(VehicleType.MOTOCYCLE)) {
            list = spots.stream()
                    .filter(spot -> spot.isAvailable())
                    .collect(Collectors.toList());
        }
        if (vehicle.getVehicleType().equals(VehicleType.CAR)) {
            list = spots.stream()
                    .filter(spot -> spot.isAvailable() && (spot.getSpotType().equals(SpotType.COMPACT) || spot.getSpotType().equals(SpotType.LARGE)))
                    .collect(Collectors.toList());
        }
        if (vehicle.getVehicleType().equals(VehicleType.BUS)) {
            list = spots.stream()
                    .filter(spot -> spot.isAvailable() && spot.getSpotType().equals(SpotType.LARGE))
                    .collect(Collectors.toList());
        }

        List<Spot> preferredList = list.stream().filter(spot -> spot.getSpotType().equals(vehicle.getPreferredParkingSpot())).collect(Collectors.toList());

        Random rand = new Random();
        int index = rand.nextInt(preferredList.size());

        return preferredList.get(index);
    }


    class Spot {
        int floorNumber;
        int spotId;
        SpotType spotType;
        boolean isAvailable;
        Vehicle vehicle;

        public int getFloorNumber() {
            return floorNumber;
        }

        public void setFloorNumber(int floorNumber) {
            this.floorNumber = floorNumber;
        }

        public int getSpotId() {
            return spotId;
        }

        public void setSpotId(int spotid) {
            this.spotId = spotid;
        }

        public SpotType getSpotType() {
            return spotType;
        }

        public void setSpotType(SpotType spotType) {
            this.spotType = spotType;
        }

        public boolean isAvailable() {
            return isAvailable;
        }

        public void setAvailable(boolean available) {
            isAvailable = available;
        }

        public Vehicle getVehicle() {
            return vehicle;
        }

        public void setVehicle(Vehicle vehicle) {
            this.vehicle = vehicle;
        }
    }

    class Vehicle {
        String plateNumber;
        VehicleType vehicleType;
        SpotType preferredParkingSpot;

        public String getPlateNumber() {
            return plateNumber;
        }

        public void setPlateNumber(String plateNumber) {
            this.plateNumber = plateNumber;
        }

        public VehicleType getVehicleType() {
            return vehicleType;
        }

        public void setVehicleType(VehicleType vehicleType) {
            this.vehicleType = vehicleType;
        }

        public SpotType getPreferredParkingSpot() {
            return preferredParkingSpot;
        }

        public void setPreferredParkingSpot(SpotType preferredParkingSpot) {
            this.preferredParkingSpot = preferredParkingSpot;
        }
    }

    enum SpotType {
        MOTOCYCLE, COMPACT, LARGE
    }

    enum VehicleType {
        MOTOCYCLE, CAR, BUS
    }

}