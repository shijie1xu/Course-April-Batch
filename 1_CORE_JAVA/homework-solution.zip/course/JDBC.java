package com.interview.coding.course;

import com.interview.coding.course.Homework_Serializable.Employee;

import java.sql.*;

public class JDBC {

    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3361/EMP";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    public Employee getEmployeeById(int id) throws Exception{
        Employee employee = new Employee();

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            String sql = "SELECT * FROM emp WHERE ID = " + id;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            String pSql = "SELECT * FROM emp WHERE ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(pSql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();

            String cSql = "{call spGetEmployee(?)}";
            CallableStatement cStmt = conn.prepareCall(cSql);
            cStmt.setInt(1, id);
            rs = cStmt.executeQuery();



            while(rs.next()){
                employee.setId(rs.getInt("id"));
                employee.setName(rs.getString("name"));
            }
            rs.close();
            stmt.close();
            conn.close();
            return employee;
        }catch(SQLException e){
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }
        finally {
            if(rs != null){
                rs.close();
                rs = null;
            }
            if(stmt != null){
                stmt.close();
                stmt = null;
            }
            if(conn != null){
                conn.close();
                conn = null;
            }
        }
        return null;
    }
}
