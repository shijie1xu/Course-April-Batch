package com.interview.coding.course.functionalinterfaceimpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyStream {

    @FunctionalInterface
    public interface funInt{
        public int convert(int x);
    }


    public static List<Integer> MyMap(List<Integer> list, funInt fi){
        List<Integer> result = new ArrayList<>();
        for(int i=0; i<list.size(); i++){
            result.add(fi.convert(list.get(i)));
        }
        return result;
    }


    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>(Arrays.asList(1,2,3,4,5));
        List<Integer> result = MyStream.MyMap(list, o->o*2);
        System.out.println(result);
    }
}
