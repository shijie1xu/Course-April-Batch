package com.interview.coding.course;

import java.util.ArrayList;
import java.util.List;

/**
 * Problems:
 * define a final class and final method and final variable,
 * modify the value of the variable in final method
 */

//final class
public final class Homework_final {

    private final String name = "Homework";
    private final List<String> nameList = new ArrayList<>();

    //final method
    public final void assignValue(){
        //cannot change final variable name;
        nameList.add("a");
    }
}

