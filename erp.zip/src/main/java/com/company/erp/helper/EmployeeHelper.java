package com.company.erp.helper;

import org.springframework.stereotype.Component;

@Component
public class EmployeeHelper {

    public String quoteString(String s){
        return "\"" + s + "\"";
    }

}
