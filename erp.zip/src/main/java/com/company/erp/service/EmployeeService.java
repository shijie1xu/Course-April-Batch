package com.company.erp.service;

import com.company.erp.dto.EmployeeDTO;
import com.company.erp.exception.EmployeeException;
import com.company.erp.dao.EmployeeDao;
import com.company.erp.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    private EmployeeDao dao;

    public EmployeeDao getDao() {
        return dao;
    }

    @Autowired
    public void setDao(EmployeeDao dao) {
        this.dao = dao;
    }

    public List<Employee> getAllEmployees() {
        return dao.getAll();
    }

    public Employee getEmployeeById(int id) {
        return dao.getEmployee(id);
    }

    public void addEmployee(Employee e) {
        dao.add(e);
    }

    public void updateEmployee(Employee e) {
        dao.update(e);
    }

    public void deleteEmployee(int id) throws EmployeeException{
        List<Employee> list = getAllEmployees();
        Employee existing = list.stream().filter(e -> id == e.getEmpId()).findFirst().orElse(null);
        if(existing == null){
            throw new EmployeeException("No employee found with id " + id);
        }else{
            dao.delete(id);
        }
    }

    public EmployeeDTO getBasicEmployee(int id) {
        return dao.getEmployeeBasic(id);
    }
}


