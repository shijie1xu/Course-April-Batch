package com.company.erp.service;

import com.company.erp.dao.EmployeeDao;
import com.company.erp.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    private EmployeeDao dao;

    public EmployeeDao getDao() {
        return dao;
    }

    @Autowired
    public void setDao(EmployeeDao dao) {
        this.dao = dao;
    }

    public List<Employee> getAllEmployees() {
        return dao.getAll();
    }

    public Employee getEmployeeById(int id) {
        return dao.getEmployee(id);
    }

    public void addEmployee(Employee e) {
        dao.add(e);
    }
}


