package com.company.erp.dao;

import com.company.erp.dto.EmployeeDTO;
import com.company.erp.helper.EmployeeHelper;
import com.company.erp.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class EmployeeDao {

    public static final String DRIVER = "com.mysql.jdbc.Driver";
    public static final String URL = "jdbc:mysql://localhost:3306/course";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "root";

    @Autowired
    EmployeeHelper helper;

    public void performEmployeeJDBC(String sql, List<Employee> employees) {
        performEmployeeJDBC(sql, employees, true);
    }

    public void performEmployeeJDBC(String sql, List<Employee> employees, boolean readOnly) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = this.getConnection();
            stmt = conn.createStatement();
            if (readOnly) {
                rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    Employee e = new Employee();
                    e.setEmpId(rs.getInt("empid"));
                    e.setName(rs.getString("name"));
                    e.setJob(rs.getString("job"));
                    e.setManager(rs.getInt("manager"));
                    e.setHireDate(rs.getDate("hiredate"));
                    e.setSalary(rs.getDouble("salary"));
                    e.setDeptId(rs.getInt("deptid"));
                    employees.add(e);
                }
                rs.close();
            } else {
                stmt.executeUpdate(sql);
            }
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                closeConnection(conn, stmt, rs);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void performEmployeeDTOJDBC(String sql, List<EmployeeDTO> employees) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = this.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                EmployeeDTO e = new EmployeeDTO(rs.getInt("empid"), rs.getString("name"), rs.getString("deptname"));
                employees.add(e);
            }
            rs.close();

            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                closeConnection(conn, stmt, rs);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public List<Employee> getAll() {
        List<Employee> employees = new ArrayList<>();
        performEmployeeJDBC("select * from course.employee", employees);
        return employees;
    }


    public Employee getEmployee(int id) {
        String sql = "select * from course.employee where empid = " + id;
        List<Employee> list = new ArrayList<>();
        performEmployeeJDBC(sql, list);
        if (list.size() != 0) {
            return list.get(0);
        }
        return null;
    }


    private Connection getConnection() throws Exception {
        Class.forName(DRIVER);
        //获取连接
        Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        return conn;
    }

    private void closeConnection(Connection conn, Statement stmt, ResultSet rs) throws SQLException {
        if (rs != null) {
            rs.close();
            rs = null;
        }
        if (stmt != null) {
            stmt.close();
            stmt = null;
        }
        if (conn != null) {
            conn.close();
            conn = null;
        }

    }

    public void add(Employee e) {
        //generate id by system
        List<Employee> list = getAll();
        int id = list.stream().map(emp -> emp.getEmpId()).reduce(Integer::max).orElse(0) + 1;
        e.setEmpId(id);

        StringBuilder sb = new StringBuilder();
        sb.append("insert into course.employee values (");
        sb.append(e.getEmpId()).append(",");
        sb.append(e.getName() == null ? "\"\"" : helper.quoteString(e.getName())).append(",");
        sb.append(e.getJob() == null ? "\"\"" : helper.quoteString(e.getJob())).append(",");
        sb.append(e.getManager()).append(",");
        sb.append(e.getHireDate() == null ? "null" : helper.quoteString(e.getHireDate().toString())).append(",");
        sb.append(e.getSalary()).append(",");
        sb.append(e.getDeptId()).append(")");

        String sql = sb.toString();
        System.out.println("---------------- SQL: " + sql);
        performEmployeeJDBC(sql, new ArrayList<>(), false);

        //insert into course.employee values (7839, 'KING', 'PRESIDENT', null, STR_TO_DATE('17-11-1981','%d-%m-%Y'), 5000, 10),
    }


    public void update(Employee e) {
        //generate id by system
        List<Employee> list = getAll();

        String template = "update course.employee set name = \"%s\" where empid = %d";
        String sql = String.format(template, e.getName(), e.getEmpId());

        System.out.println("---------------- SQL: " + sql);
        performEmployeeJDBC(sql, new ArrayList<>(), false);

        //update employee set name = NEW-NAME where empid = GET-ID
    }

    public void delete(int id) {
        //generate id by system
        List<Employee> list = getAll();

        String template = "delete from course.employee where empid = %d";
        String sql = String.format(template, id);

        System.out.println("---------------- SQL: " + sql);
        performEmployeeJDBC(sql, new ArrayList<>(), false);

        //delete employee where empid = GET-ID
    }

    public EmployeeDTO getEmployeeBasic(int id) {
        String sql = "select e.empid, e.name, d.name as deptname from course.employee e join course.department d on e.deptid = d.deptid where e.empid = " + id;
        List<EmployeeDTO> list = new ArrayList<>();
        performEmployeeDTOJDBC(sql, list);
        if (list.size() != 0) {
            return list.get(0);
        }
        return null;
    }
}
